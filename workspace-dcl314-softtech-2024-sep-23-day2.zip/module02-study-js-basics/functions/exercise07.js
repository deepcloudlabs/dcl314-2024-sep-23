function fun() {
    a = 5; // creates a global variable called "a"
}

fun();
console.log(a);
