function fun() {
    var a = 5; // creates a local variable called "a"
}

fun();
console.log(a);
