function fun() {
    let a = 5; // creates a local variable called "a"
}

fun();
console.log(a);
