function fun() {
    for(let i = 0;i < 10;++i){
        console.log(`[in the loop] i: ${i}`);
    }
    console.log(`[after the loop] i: ${i}`);
}

fun();
