x = "izmir";
console.log(x.toUpperCase());
console.log(x.toLocaleUpperCase("tr"));
x = "ISPARTA";
console.log(x.toLowerCase());
console.log(x.toLocaleLowerCase("tr"));
