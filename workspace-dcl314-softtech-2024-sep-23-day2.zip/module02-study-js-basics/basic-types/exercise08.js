console.log(isNaN("three"));
console.log(Number.isNaN("three"));
