x = 0 / 0
console.log(x)
if (Number.isNaN(x))
    y = 0;
else
    y = 0 * x;
console.log(y)
