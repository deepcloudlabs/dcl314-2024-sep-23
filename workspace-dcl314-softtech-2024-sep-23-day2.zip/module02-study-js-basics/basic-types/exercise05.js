x = (0.1 + 0.2) + 0.3
y = 0.1 + (0.2 + 0.3)
console.log(x)
console.log(y)
console.log(x === y)
