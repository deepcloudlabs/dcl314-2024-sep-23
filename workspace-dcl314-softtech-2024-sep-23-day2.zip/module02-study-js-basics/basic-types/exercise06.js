x = 100000000000000100
console.log(x)
y = x + 50
console.log(y)

