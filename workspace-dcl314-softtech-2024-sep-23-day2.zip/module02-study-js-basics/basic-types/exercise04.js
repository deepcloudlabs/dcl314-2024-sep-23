x = 2.0;
y = x - 1.10;
z = 1_000_000 * y
console.log(y)
console.log(z)
