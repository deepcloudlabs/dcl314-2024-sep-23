x = -1 / 0;
y = 0 * x;
console.log(x);
console.log(y);
