x = "\u20ba";
console.log(x)
x = "\ud834\udd1e";
console.log(x)
console.log(x.length)
