x = 1 + 2 + Number("3")
console.log(x)
