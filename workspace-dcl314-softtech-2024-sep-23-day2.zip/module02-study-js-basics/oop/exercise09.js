class Customer {

}

class GoldCustomer extends Customer {}

class Employee {
    fun = () => {}
}

class Engineer extends Employee {}

class Manager extends Employee {}

class Director extends Manager {}
