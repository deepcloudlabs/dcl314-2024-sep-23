numbers = [4, 8, 15, 16, 23, 42]
console.log(numbers)
console.log(numbers.length)
