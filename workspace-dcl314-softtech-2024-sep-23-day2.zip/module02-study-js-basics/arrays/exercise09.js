numbers = [4, 8, 15, 16, 23, 42]
console.log(numbers.includes(42)) // true
console.log(numbers.includes(37)) // false
console.log(numbers.indexOf(42)) // 5   >= 0: -> true
console.log(numbers.indexOf(37)) // -1  <0  : -> false
