numbers = [4, 8, 15, 16, 23, 42]
console.log(numbers[-1])
console.log(numbers[6])
console.log(numbers[16])
console.log(numbers[-100])
