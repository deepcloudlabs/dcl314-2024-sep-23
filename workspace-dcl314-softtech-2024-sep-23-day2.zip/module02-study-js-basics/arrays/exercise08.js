numbers = [4, 8, 15, 16, 23, 42]
let sum = numbers.reduce((acc, number) => acc + number)
console.log(sum)
