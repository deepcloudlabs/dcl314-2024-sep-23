numbers = [4, 8, 15, 16, 23, 42]
let sum = 0
for (let i = 0; i < numbers.length; i++) { // external loop
    sum += numbers[i]
}
console.log(sum)
