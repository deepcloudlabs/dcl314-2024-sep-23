x = "zehra"
y = "şule"
console.log(x.localeCompare(y))
