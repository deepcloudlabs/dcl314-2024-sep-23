numbers = [4, 8, 15, 16, 23, 42]
let sum = 0
for (let i in numbers) { // external loop
    sum += numbers[i]
}
console.log(sum)
