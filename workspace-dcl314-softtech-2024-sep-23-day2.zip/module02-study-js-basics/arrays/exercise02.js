numbers = [4, 8, 15, 16, 23, 42]
console.log(numbers[0])
console.log(numbers[1])
console.log(numbers[2])
console.log(numbers[5])
