numbers = [4, 8, 15, 16, 23, 42]
let sum = 0
numbers.forEach(number => { // internal loop
    sum += number
})
console.log(sum)
